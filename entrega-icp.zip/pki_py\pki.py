
import os, sys, argparse, datetime, pathlib, hashlib, re
from typing import Optional
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.x509.oid import NameOID, ExtendedKeyUsageOID, ObjectIdentifier

BASE = pathlib.Path("pki")
OID_CPF  = ObjectIdentifier("2.16.76.1.3.1")
OID_CNPJ = ObjectIdentifier("2.16.76.1.3.3")

def only_digits(s: Optional[str]) -> Optional[str]:
    if s is None:
        return None
    return re.sub(r"\D+", "", s)

def der_utf8_string(value: str) -> bytes:
    data = value.encode("utf-8")
    if len(data) > 127:
        raise ValueError("Valor muito grande para este encoder simples.")
    return bytes([0x0C, len(data)]) + data

def save_pem_key(private_key, path: pathlib.Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.TraditionalOpenSSL,
        encryption_algorithm=serialization.NoEncryption(),
    )
    path.write_bytes(pem)

def save_pem_cert(cert: x509.Certificate, path: pathlib.Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(cert.public_bytes(serialization.Encoding.PEM))

def save_pem_csr(csr: x509.CertificateSigningRequest, path: pathlib.Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(csr.public_bytes(serialization.Encoding.PEM))

def load_pem_cert(path: pathlib.Path) -> x509.Certificate:
    return x509.load_pem_x509_certificate(path.read_bytes())

def load_pem_key(path: pathlib.Path):
    return serialization.load_pem_private_key(path.read_bytes(), password=None)

def utcnow():
    return datetime.datetime.now(datetime.UTC)

def cmd_init(_args):
    for p in [
        BASE / "raiz-ca" / "certs",
        BASE / "raiz-ca" / "crl",
        BASE / "raiz-ca" / "newcerts",
        BASE / "raiz-ca" / "private",
        BASE / "ca-intermediaria" / "certs",
        BASE / "ca-intermediaria" / "crl",
        BASE / "ca-intermediaria" / "newcerts",
        BASE / "ca-intermediaria" / "private",
        BASE / "ca-intermediaria" / "csr",
        BASE / "usuarios" / "luis",
        BASE / "usuarios" / "monica",
        BASE / "usuarios" / "gustavo",
    ]:
        p.mkdir(parents=True, exist_ok=True)
    print("[OK] Estrutura criada em 'pki/'.")

def generate_root_ca():
    key = rsa.generate_private_key(public_exponent=65537, key_size=4096)
    subject = issuer = x509.Name([
        x509.NameAttribute(NameOID.COUNTRY_NAME, "BR"),
        x509.NameAttribute(NameOID.ORGANIZATION_NAME, "Mini ICP-Brasil"),
        x509.NameAttribute(NameOID.ORGANIZATIONAL_UNIT_NAME, "Autoridade Certificadora Raiz"),
        x509.NameAttribute(NameOID.COMMON_NAME, "Mini ICP-Brasil Root CA"),
        x509.NameAttribute(NameOID.EMAIL_ADDRESS, "acraiz@example.com"),
    ])
    now = utcnow()
    builder = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now - datetime.timedelta(days=1))
        .not_valid_after(now + datetime.timedelta(days=3650))
        .add_extension(x509.BasicConstraints(ca=True, path_length=None), critical=True)
        .add_extension(x509.KeyUsage(
            digital_signature=False, content_commitment=False, key_encipherment=False,
            data_encipherment=False, key_agreement=False, key_cert_sign=True, crl_sign=True,
            encipher_only=False, decipher_only=False
        ), critical=True)
        .add_extension(x509.SubjectKeyIdentifier.from_public_key(key.public_key()), critical=False)
        .add_extension(x509.AuthorityKeyIdentifier.from_issuer_public_key(key.public_key()), critical=False)
    )
    cert = builder.sign(private_key=key, algorithm=hashes.SHA256())
    return key, cert

def cmd_gen_root(_args):
    key, cert = generate_root_ca()
    save_pem_key(key,  BASE / "raiz-ca" / "private" / "rootCA.key.pem")
    save_pem_cert(cert, BASE / "raiz-ca" / "certs"  / "rootCA.crt")
    print("[OK] CA-Raiz gerada: pki/raiz-ca/certs/rootCA.crt")

def generate_intermediate_csr(int_key):
    subject = x509.Name([
        x509.NameAttribute(NameOID.COUNTRY_NAME, "BR"),
        x509.NameAttribute(NameOID.ORGANIZATION_NAME, "Mini ICP-Brasil"),
        x509.NameAttribute(NameOID.ORGANIZATIONAL_UNIT_NAME, "Autoridade Certificadora Intermediária"),
        x509.NameAttribute(NameOID.COMMON_NAME, "Mini ICP-Brasil Intermediate CA"),
        x509.NameAttribute(NameOID.EMAIL_ADDRESS, "acinter@example.com"),
    ])
    csr = (
        x509.CertificateSigningRequestBuilder()
        .subject_name(subject)
        .sign(private_key=int_key, algorithm=hashes.SHA256())
    )
    return csr

def sign_intermediate_with_root(root_key, root_cert, int_key, csr):
    now = utcnow()
    builder = (
        x509.CertificateBuilder()
        .subject_name(csr.subject)
        .issuer_name(root_cert.subject)
        .public_key(int_key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now - datetime.timedelta(days=1))
        .not_valid_after(now + datetime.timedelta(days=1825))
        .add_extension(x509.BasicConstraints(ca=True, path_length=0), critical=True)
        .add_extension(x509.KeyUsage(
            digital_signature=False, content_commitment=False, key_encipherment=False,
            data_encipherment=False, key_agreement=False, key_cert_sign=True, crl_sign=True,
            encipher_only=False, decipher_only=False
        ), critical=True)
        .add_extension(x509.SubjectKeyIdentifier.from_public_key(int_key.public_key()), critical=False)
        .add_extension(x509.AuthorityKeyIdentifier.from_issuer_public_key(root_key.public_key()), critical=False)
    )
    cert = builder.sign(private_key=root_key, algorithm=hashes.SHA256())
    return cert

def cmd_gen_intermediate(_args):
    int_key = rsa.generate_private_key(public_exponent=65537, key_size=4096)
    csr = generate_intermediate_csr(int_key)
    save_pem_csr(csr, BASE / "ca-intermediaria" / "csr" / "intermediate.csr")
    root_key = load_pem_key(BASE / "raiz-ca" / "private" / "rootCA.key.pem")
    root_crt = load_pem_cert(BASE / "raiz-ca" / "certs" / "rootCA.crt")
    int_cert = sign_intermediate_with_root(root_key, root_crt, int_key, csr)
    save_pem_key(int_key,  BASE / "ca-intermediaria" / "private" / "intermediateCA.key.pem")
    save_pem_cert(int_cert, BASE / "ca-intermediaria" / "certs"  / "intermediateCA.crt")
    chain_path = BASE / "ca-intermediaria" / "certs" / "ca-chain.pem"
    chain_path.write_bytes(int_cert.public_bytes(serialization.Encoding.PEM) + root_crt.public_bytes(serialization.Encoding.PEM))
    print("[OK] CA Intermediária gerada; CSR e certificado salvos.")

def generate_user_csr(name: str, cn: str, email: str, cpf: Optional[str], cnpj: Optional[str], user_key):
    subject = x509.Name([
        x509.NameAttribute(NameOID.COUNTRY_NAME, "BR"),
        x509.NameAttribute(NameOID.ORGANIZATION_NAME, "Pessoa Fisica" if cpf else "Pessoa Juridica"),
        x509.NameAttribute(NameOID.COMMON_NAME, cn),
    ])
    san_elems = [x509.RFC822Name(email)]
    ncpf  = only_digits(cpf)
    ncnpj = only_digits(cnpj)
    if ncpf:
        san_elems.append(x509.OtherName(OID_CPF, der_utf8_string(ncpf)))
    if ncnpj:
        san_elems.append(x509.OtherName(OID_CNPJ, der_utf8_string(ncnpj)))
    csr = (
        x509.CertificateSigningRequestBuilder()
        .subject_name(subject)
        .add_extension(x509.SubjectAlternativeName(san_elems), critical=False)
        .sign(private_key=user_key, algorithm=hashes.SHA256())
    )
    return csr

def sign_user_with_intermediate(int_key, int_cert, user_key, csr):
    now = utcnow()
    builder = (
        x509.CertificateBuilder()
        .subject_name(csr.subject)
        .issuer_name(int_cert.subject)
        .public_key(user_key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now - datetime.timedelta(days=1))
        .not_valid_after(now + datetime.timedelta(days=730))
        .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
        .add_extension(x509.KeyUsage(
            digital_signature=True, content_commitment=False, key_encipherment=True,
            data_encipherment=False, key_agreement=False, key_cert_sign=False, crl_sign=False,
            encipher_only=False, decipher_only=False
        ), critical=True)
        .add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.CLIENT_AUTH, ExtendedKeyUsageOID.EMAIL_PROTECTION]), critical=False)
        .add_extension(x509.SubjectKeyIdentifier.from_public_key(user_key.public_key()), critical=False)
        .add_extension(x509.AuthorityKeyIdentifier.from_issuer_public_key(int_key.public_key()), critical=False)
    )
    cert = builder.sign(private_key=int_key, algorithm=hashes.SHA256())
    return cert

def cmd_gen_user(args):
    int_key = load_pem_key(BASE / "ca-intermediaria" / "private" / "intermediateCA.key.pem")
    int_crt = load_pem_cert(BASE / "ca-intermediaria" / "certs" / "intermediateCA.crt")

    user_dir = BASE / "usuarios" / args.name
    (user_dir / "private").mkdir(parents=True, exist_ok=True)
    (user_dir / "csr").mkdir(parents=True, exist_ok=True)
    (user_dir / "certs").mkdir(parents=True, exist_ok=True)

    user_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    save_pem_key(user_key, user_dir / "private" / f"{args.name}.key.pem")

    csr = generate_user_csr(args.name, args.cn, args.email, args.cpf, args.cnpj, user_key)
    save_pem_csr(csr, user_dir / "csr" / f"{args.name}.csr")

    cert = sign_user_with_intermediate(int_key, int_crt, user_key, csr)
    save_pem_cert(cert, user_dir / "certs"  / f"{args.name}.crt")

    chain = (BASE / "ca-intermediaria" / "certs" / "ca-chain.pem").read_bytes()
    (user_dir / "certs" / "ca-chain.pem").write_bytes(chain)

    print(f"[OK] Certificado emitido para {args.name} (CSR e cert salvos).")

def cmd_sign(args):
    data = pathlib.Path(args.file).read_bytes()
    priv = load_pem_key(pathlib.Path(args.key))
    signature = priv.sign(data, padding.PKCS1v15(), hashes.SHA256())
    sig_path = pathlib.Path(args.file + ".assinatura")
    sig_path.write_bytes(signature)
    h = hashlib.sha256(data).hexdigest()
    pathlib.Path(args.file + ".sha256").write_text(h, encoding="utf-8")
    print(f"[OK] Assinatura gerada: {sig_path.name} (SHA256={h})")

def verify_cert_signed_by(issuer_cert: x509.Certificate, subject_cert: x509.Certificate) -> bool:
    pub = issuer_cert.public_key()
    try:
        pub.verify(
            subject_cert.signature,
            subject_cert.tbs_certificate_bytes,
            padding.PKCS1v15(),
            subject_cert.signature_hash_algorithm,
        )
        return True
    except Exception:
        return False

def check_time_valid(cert: x509.Certificate) -> bool:
    now = utcnow()
    return cert.not_valid_before_utc <= now <= cert.not_valid_after_utc

def get_basic_constraints(cert: x509.Certificate) -> x509.BasicConstraints:
    return cert.extensions.get_extension_for_class(x509.BasicConstraints).value

def get_key_usage(cert: x509.Certificate) -> x509.KeyUsage:
    return cert.extensions.get_extension_for_class(x509.KeyUsage).value

def load_optional_crl(path: Optional[str]):
    if not path:
        return None
    p = pathlib.Path(path)
    if not p.exists():
        raise FileNotFoundError(f"CRL não encontrada: {path}")
    return x509.load_pem_x509_crl(p.read_bytes())

def is_revoked(crl: x509.CertificateRevocationList, cert: x509.Certificate) -> bool:
    for r in crl:
        if r.serial_number == cert.serial_number:
            return True
    return False

def cmd_verify(args):
    data = pathlib.Path(args.file).read_bytes()
    signature = pathlib.Path(args.sig).read_bytes()
    user_cert = load_pem_cert(pathlib.Path(args.cert))
    chain_cert = load_pem_cert(pathlib.Path(args.chain))
    root_cert  = load_pem_cert(pathlib.Path(args.root))

    pub = user_cert.public_key()
    try:
        pub.verify(signature, data, padding.PKCS1v15(), hashes.SHA256())
    except Exception:
        print("Falha de verificação: assinatura inválida do arquivo.")
        sys.exit(1)

    if not (check_time_valid(user_cert) and check_time_valid(chain_cert) and check_time_valid(root_cert)):
        print("Falha de verificação: certificado fora do período de validade.")
        sys.exit(1)

    if not verify_cert_signed_by(chain_cert, user_cert):
        print("Falha de verificação: usuário não foi assinado pela intermediária informada.")
        sys.exit(1)
    if not verify_cert_signed_by(root_cert, chain_cert):
        print("Falha de verificação: intermediária não foi assinada pela raiz informada.")
        sys.exit(1)

    bc_user = get_basic_constraints(user_cert)
    bc_int  = get_basic_constraints(chain_cert)
    bc_root = get_basic_constraints(root_cert)
    if bc_user.ca:
        print("Falha: certificado do usuário NÃO deve ser CA.")
        sys.exit(1)
    if not bc_int.ca or (bc_int.path_length is not None and bc_int.path_length != 0):
        print("Falha: intermediária deve ser CA com pathlen=0.")
        sys.exit(1)
    if not bc_root.ca:
        print("Falha: raiz deve ser CA.")
        sys.exit(1)

    ku_int = get_key_usage(chain_cert)
    ku_root = get_key_usage(root_cert)
    if not (ku_int.key_cert_sign and ku_int.crl_sign):
        print("Falha: intermediária deve ter keyCertSign e cRLSign.")
        sys.exit(1)
    if not (ku_root.key_cert_sign and ku_root.crl_sign):
        print("Falha: raiz deve ter keyCertSign e cRLSign.")
        sys.exit(1)

    crl = load_optional_crl(args.crl)
    if crl is not None and is_revoked(crl, user_cert):
        print("Falha de verificação: certificado do usuário está REVOGADO (CRL).")
        sys.exit(1)

    print("[OK] Assinatura válida e cadeia confiável.")

def cmd_fakeca(_args):
    fake_dir = BASE / "fakeca"
    (fake_dir / "certs").mkdir(parents=True, exist_ok=True)
    (fake_dir / "private").mkdir(parents=True, exist_ok=True)
    (fake_dir / "csr").mkdir(parents=True, exist_ok=True)

    fkey = rsa.generate_private_key(public_exponent=65537, key_size=4096)
    subject = issuer = x509.Name([
        x509.NameAttribute(NameOID.COUNTRY_NAME, "BR"),
        x509.NameAttribute(NameOID.ORGANIZATION_NAME, "FakeCA"),
        x509.NameAttribute(NameOID.ORGANIZATIONAL_UNIT_NAME, "Fraude"),
        x509.NameAttribute(NameOID.COMMON_NAME, "Fake Root"),
        x509.NameAttribute(NameOID.EMAIL_ADDRESS, "fake@example.com"),
    ])
    now = utcnow()
    froot = (
        x509.CertificateBuilder()
        .subject_name(subject).issuer_name(issuer).public_key(fkey.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now - datetime.timedelta(days=1))
        .not_valid_after(now + datetime.timedelta(days=3650))
        .add_extension(x509.BasicConstraints(ca=True, path_length=None), critical=True)
        .add_extension(x509.KeyUsage(
            digital_signature=False, content_commitment=False, key_encipherment=False,
            data_encipherment=False, key_agreement=False, key_cert_sign=True, crl_sign=True,
            encipher_only=False, decipher_only=False
        ), critical=True)
        .add_extension(x509.SubjectKeyIdentifier.from_public_key(fkey.public_key()), critical=False)
        .add_extension(x509.AuthorityKeyIdentifier.from_issuer_public_key(fkey.public_key()), critical=False)
        .sign(private_key=fkey, algorithm=hashes.SHA256())
    )
    (fake_dir / "private" / "fakeCA.key.pem").write_bytes(
        fkey.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.TraditionalOpenSSL, serialization.NoEncryption())
    )
    (fake_dir / "certs" / "fakeCA.crt").write_bytes(
        froot.public_bytes(serialization.Encoding.PEM)
    )

    atk_dir = BASE / "usuarios" / "gustavo"
    (atk_dir / "private").mkdir(parents=True, exist_ok=True)
    (atk_dir / "certs").mkdir(parents=True, exist_ok=True)

    akey = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    asub = x509.Name([
        x509.NameAttribute(NameOID.COUNTRY_NAME, "BR"),
        x509.NameAttribute(NameOID.ORGANIZATION_NAME, "Pessoa Fisica"),
        x509.NameAttribute(NameOID.COMMON_NAME, "Gustavo Pereira"),
        x509.NameAttribute(NameOID.EMAIL_ADDRESS, "gustavo@example.com"),
    ])
    acert = (
        x509.CertificateBuilder()
        .subject_name(asub).issuer_name(froot.subject).public_key(akey.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now - datetime.timedelta(days=1))
        .not_valid_after(now + datetime.timedelta(days=365))
        .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
        .add_extension(x509.KeyUsage(
            digital_signature=True, content_commitment=False, key_encipherment=True,
            data_encipherment=False, key_agreement=False, key_cert_sign=False, crl_sign=False,
            encipher_only=False, decipher_only=False
        ), critical=True)
        .add_extension(x509.SubjectKeyIdentifier.from_public_key(akey.public_key()), critical=False)
        .add_extension(x509.AuthorityKeyIdentifier.from_issuer_public_key(fkey.public_key()), critical=False)
        .sign(private_key=fkey, algorithm=hashes.SHA256())
    )
    (atk_dir / "private" / "gustavo.key.pem").write_bytes(
        akey.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.TraditionalOpenSSL, serialization.NoEncryption())
    )
    (atk_dir / "certs" / "gustavo.crt").write_bytes(
        acert.public_bytes(serialization.Encoding.PEM)
    )
    print("[OK] FakeCA e certificado de 'gustavo' gerados.")

def cmd_revoke(args):
    int_key = load_pem_key(BASE / "ca-intermediaria" / "private" / "intermediateCA.key.pem")
    int_crt = load_pem_cert(BASE / "ca-intermediaria" / "certs" / "intermediateCA.crt")
    user_crt = load_pem_cert(BASE / "usuarios" / args.user / "certs" / f"{args.user}.crt")

    now = utcnow()
    crl_builder = x509.CertificateRevocationListBuilder().issuer_name(
        int_crt.subject
    ).last_update(
        now - datetime.timedelta(minutes=1)
    ).next_update(
        now + datetime.timedelta(days=7)
    )

    revoked = x509.RevokedCertificateBuilder().serial_number(
        user_crt.serial_number
    ).revocation_date(
        now
    ).build()

    crl = crl_builder.add_revoked_certificate(revoked).sign(
        private_key=int_key, algorithm=hashes.SHA256()
    )

    crl_dir = BASE / "ca-intermediaria" / "crl"
    crl_dir.mkdir(parents=True, exist_ok=True)
    (crl_dir / "intermediateCA.crl.pem").write_bytes(
        crl.public_bytes(serialization.Encoding.PEM)
    )
    print(f"[OK] CRL gerada com revogação do usuário '{args.user}'.")

def cmd_demo(_args):
    cmd_init(None)
    cmd_gen_root(None)
    cmd_gen_intermediate(None)
    class A: pass
    a=A(); a.name="luis"; a.cn="Luis da Silva"; a.email="luis@example.com"; a.cpf="123.456.789-00"; a.cnpj=None
    cmd_gen_user(a)
    b=A(); b.name="monica"; b.cn="Monica Oliveira"; b.email="monica@example.com"; b.cpf="987.654.321-00"; b.cnpj=None
    cmd_gen_user(b)
    pathlib.Path("docs").mkdir(exist_ok=True)
    pathlib.Path("docs/contrato.txt").write_text("Contrato - Exemplo (Luis/Monica/Gustavo)", encoding="utf-8")
    class S: pass
    s=S(); s.file="docs/contrato.txt"; s.key="pki/usuarios/luis/private/luis.key.pem"
    cmd_sign(s)
    v=S(); v.file="docs/contrato.txt"; v.sig="docs/contrato.txt.assinatura"; v.cert="pki/usuarios/luis/certs/luis.crt"; v.chain="pki/ca-intermediaria/certs/intermediateCA.crt"; v.root="pki/raiz-ca/certs/rootCA.crt"; v.crl=None
    cmd_verify(v)
    cmd_fakeca(None)
    s2=S(); s2.file="docs/contrato.txt"; s2.key="pki/usuarios/gustavo/private/gustavo.key.pem"
    cmd_sign(s2)
    v2=S(); v2.file="docs/contrato.txt"; v2.sig="docs/contrato.txt.assinatura"; v2.cert="pki/usuarios/gustavo/certs/gustavo.crt"; v2.chain="pki/ca-intermediaria/certs/intermediateCA.crt"; v2.root="pki/raiz-ca/certs/rootCA.crt"; v2.crl=None
    try:
        cmd_verify(v2)
    except SystemExit:
        pass
    print("------- FIM DEMO -------")

def main():
    p = argparse.ArgumentParser(description="Atividade — Sistemas ICP (Python) — luis/monica/gustavo")
    sub = p.add_subparsers(dest="cmd", required=True)

    sub.add_parser("init")
    sub.add_parser("gen-root")
    sub.add_parser("gen-intermediate")

    u = sub.add_parser("gen-user")
    u.add_argument("--name", required=True)
    u.add_argument("--cn", required=True, help="Common Name (nome no certificado)")
    u.add_argument("--email", required=True)
    u.add_argument("--cpf", help="CPF (com ou sem pontuação)")
    u.add_argument("--cnpj", help="CNPJ (com ou sem pontuação)")

    s = sub.add_parser("sign")
    s.add_argument("--file", required=True)
    s.add_argument("--key", required=True)

    v = sub.add_parser("verify")
    v.add_argument("--file", required=True)
    v.add_argument("--sig", required=True, help="Caminho do arquivo .assinatura")
    v.add_argument("--cert", required=True, help="Certificado do usuário (PEM)")
    v.add_argument("--chain", required=True, help="Certificado da intermediária (PEM)")
    v.add_argument("--root", required=True, help="Certificado da raiz (PEM)")
    v.add_argument("--crl", required=False, help="(Opcional) CRL PEM da intermediária")

    sub.add_parser("fakeca")

    r = sub.add_parser("revoke")
    r.add_argument("--user", required=True)

    sub.add_parser("demo")

    args = p.parse_args()
    if args.cmd == "init":
        cmd_init(args)
    elif args.cmd == "gen-root":
        cmd_gen_root(args)
    elif args.cmd == "gen-intermediate":
        cmd_gen_intermediate(args)
    elif args.cmd == "gen-user":
        cmd_gen_user(args)
    elif args.cmd == "sign":
        cmd_sign(args)
    elif args.cmd == "verify":
        cmd_verify(args)
    elif args.cmd == "fakeca":
        cmd_fakeca(args)
    elif args.cmd == "revoke":
        cmd_revoke(args)
    elif args.cmd == "demo":
        cmd_demo(args)
    else:
        p.print_help()

if __name__ == "__main__":
    main()
